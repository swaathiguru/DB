import cx_Oracle
import csv

dsn_tns = cx_Oracle.makedsn('az6F72ldbp1.az.uta.edu', '1523', service_name='pcse1p.data.uta.edu')
conn = cx_Oracle.connect(user='sxg5126', password='Oracledatabase11', dsn=dsn_tns)

c = conn.cursor()

c.setinputsizes(None, 25)

# Adjust the number of rows to be inserted in each iteration
# to meet your memory and performance requirements
batch_size = 100

with open('data/EMPLOYEE.csv', 'r') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    sql = "insert into EMPLOYEE (Fname,Minit,Lname,Ssn,Bdate,Address,Sex,Salary,Super_ssn,Dno) values (:0,:1, :2,:3,:4,:5,:6,:7,:8,:9)"
    data = []
    for line in csv_reader:
        print(line)
        data.append((line[0],line[1],line[2],line[3],line[4],line[5],line[6],line[7],line[8],line[9]))
        print(data)
        c.executemany(sql, data)
        data = []
        
    conn.commit()