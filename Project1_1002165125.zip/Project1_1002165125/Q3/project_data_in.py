import cx_Oracle
import csv

dsn_tns = cx_Oracle.makedsn('az6F72ldbp1.az.uta.edu', '1523', service_name='pcse1p.data.uta.edu')
conn = cx_Oracle.connect(user='sxg5126', password='Oracledatabase11', dsn=dsn_tns)

c = conn.cursor()

c.setinputsizes(None, 25)

# Adjust the number of rows to be inserted in each iteration
# to meet your memory and performance requirements
batch_size = 100

with open('data/PROJECT.csv', 'r') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    sql = "insert into PROJECT(Pname,Pnumber,Plocation,Dnum) values (:0,:1,:2,:3)"
    data = []
    for line in csv_reader:
        data.append((line[0],line[1],line[2],line[3]))
        if len(data) % batch_size == 0:
            c.executemany(sql, data)
            data = []
    if data:
        c.executemany(sql, data)
    conn.commit()