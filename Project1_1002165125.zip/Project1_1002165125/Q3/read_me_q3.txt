Name : Swaathi Gurumaharaj 
UTA ID : 1002165125

Question 3 :

Python was the preferred language for loading the data into the tables. Following is the order of executing the python files for loading the data.

1. python DB/emp_dummy_data_in.py 
	
	this will insert all the employee dummy data into the corresponding table. This ensures that the foreign keys specified records will get inserted into the employee table. 

2. python DB/dept_dummy_data_in.py

	this will insert all the dept dummy data into the corresponding table. This ensures that the foreign keys specified records will get inserted into the dept table. 

3. python DB/emp_data_in.py

	this will insert the employee data into the employee table.

4. python DB/dept_data_in.py

	this will insert the department data into the department table.

5. start dept_update.txt

	this sql command will merge the department dummy values into the department table.

6. Python DB/dept_loc_data_in.py

	this will insert the department location data into the corresponding table

7. Python project_data_in.py

	this will insert the project data into the corresponding table

8. Python works_data_in.py

	this will insert the works_on data into the corresponding table

9. Python dependent_data_in.py

	this will insert the dependent data into the corresponding table
  