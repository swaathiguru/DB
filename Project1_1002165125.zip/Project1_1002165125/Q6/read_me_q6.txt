Name : Swaathi Gurumaharaj 
UTA ID : 1002165125

Question 6 :

The queries are listed in the insert_elements.sql file to insert the tuples in the table that violate the different integrity constraints.

Q6.lst is the spool file which holds the output of the executed query.