create table EMPLOYEE (
  Fname varchar(15),
	Minit char,
	Lname varchar(15),
	Ssn char(9),
	Bdate date,
	Address varchar (100),
	Sex char,
	Salary int,
	Super_ssn char(9),
	Dno int, 
	Overtimecount int,
	primary key (Ssn),
	foreign key (Super_ssn) references EMPLOYEE (Ssn)
);

create table DEPARTMENT (
	Dname varchar (20),
	Dnumber int,
	Mgr_ssn char(9),
	Mgr_start_date date,
	primary key (Dnumber),
	unique (Dname),
	foreign key (Mgr_ssn) references EMPLOYEE (Ssn)
);
create table DEPT_DUMMY (
	Dname varchar (20),
	Dnumber int,
	Mgr_ssn char(9),
	Mgr_start_date date,
	primary key (Dnumber),
	unique (Dname),
	foreign key (Mgr_ssn) references EMPLOYEE (Ssn)
);
ALTER TABLE EMPLOYEE ADD foreign key (Dno) references DEPARTMENT (Dnumber);

CREATE table DEPT_LOCATIONS (
	Dnumber int,
	Dlocation varchar(20),
	primary key (Dlocation, Dnumber),
	foreign key (Dnumber) references DEPARTMENT (Dnumber)
);

create table PROJECT (
	Pname varchar(25),
	Pnumber int,
	Plocation varchar(25),
	Dnum int,
	primary key (Pnumber),
	foreign key (Dnum) references DEPARTMENT (Dnumber)
);

create table WORKS_ON (
	Essn char(9),
	Pno int,
	Hours float,
	primary key (Essn, Pno),
	foreign key (Essn) references EMPLOYEE (Ssn),
	foreign key (Pno) references PROJECT (Pnumber)
);

create table DEPENDENT (
	Essn char(9),
	Dependent_name varchar(20),
	Sex char,
	Bdate date,
	Relationship varchar(20),
	primary key (Essn, Dependent_name),
	foreign key (Essn) references EMPLOYEE (Ssn)
);