Name : Swaathi Gurumaharaj 
UTA ID : 1002165125

Question 2 :

The sql queries to create the tables of the company schema have been provided in the ‘create_table.sql’.

‘Q2.lst’ is the spool file that was created after executing the sql file.

