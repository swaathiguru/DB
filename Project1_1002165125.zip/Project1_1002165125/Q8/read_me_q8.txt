Name : Swaathi Gurumaharaj 
UTA ID : 1002165125

Question 8 :

The sql queries are listed in the insert_noconstrnt.sql

Q8.lst has the output that was generated for the sql query.
