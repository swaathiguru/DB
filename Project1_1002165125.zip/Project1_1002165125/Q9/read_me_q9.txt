Name : Swaathi Gurumaharaj 
UTA ID : 1002165125

Question 9 :

The sql query for creating a trigger can be found in the overcount_trigger.sql

Q9.lst has the output that was generated for the sql query.