CREATE TRIGGER UpdTOverTimeCnt
AFTER INSERT ON WORKS_ON
FOR EACH ROW
BEGIN
    IF :NEW.Hours > 40 THEN
        UPDATE EMPLOYEE
        SET OverTimeCount = Coalesce(OverTimeCount, 0) + 1
        WHERE Ssn = :NEW.Essn;
    END IF;
END;