Name : Swaathi Gurumaharaj 
UTA ID : 1002165125

Question 7 :

The sql queries are listed in the delete_record.sql

Q7.lst has the output that was generated for the sql query.
