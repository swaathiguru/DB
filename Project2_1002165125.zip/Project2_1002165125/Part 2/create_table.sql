create table Library (
	Library_id varchar(10),
	LName varchar(10),
	LPin varchar(10),
	primary key (Library_id)
);

create table Books (
	BLib_id VARCHAR (10),
	book_id varchar (10),
	Author varchar(10),
	Title varchar(10),
	Sub_area VARCHAR (10),
	book_description varchar (100),
	primary key (Book_id),
	unique key (book_description),
	foreign key (BLib_id) references Library (Library_id)
);

create table Members (
	MLib_id VARCHAR (10),
	Mbook_id VARCHAR (10),
	member_id varchar(10),
	email VARCHAR (20),
	name varchar(10),
	primary key (member_id),
	foreign key (Mbook_id) references books (Book_id),
	foreign key (MLib_id) references library (library_id)
);

create table Lib_card (
	card_id varchar(10),
	mem_id varchar(10),
	date_of_expiry date,
	primary key (card_id),
	foreign key (mem_id) references members (member_id)
);

create table ref_librarian (
	rstaff_id varchar(10),
	name varchar(10),
	address varchar(25),
	Rlib_id varchar(10),
	primary key (rstaff_id),
	foreign key (Rlib_id) references Library (Library_id)
);

create table checkout_staff (
	cstaff_id varchar(10),
	name varchar(10),
	address varchar(25),
	Clib_id varchar(10),
	primary key (cstaff_id),
	foreign key (Clib_id) references Library (Library_id)
);

create table Dept_associate (
	dstaff_id varchar(10),
	name varchar(10),
	address varchar(25),
	dlib_id varchar(10),
	primary key (dstaff_id),
	foreign key (dlib_id) references Library (Library_id)
);

create table Chief_librarian (
	chstaff_id varchar(10),
	name varchar(10),
	address varchar(25),
	chlib_id varchar(10),
	primary key (chstaff_id),
	foreign key (chlib_id) references Library (Library_id)
);

create table Assisstants (
	astaff_id varchar(10),
	name varchar(10),
	address varchar(25),
	alib_id varchar(10),
	primary key (astaff_id),
	foreign key (alib_id) references Library (Library_id)
);

create table Mem_student (
	SLib_id VARCHAR (10),
	Sbook_id VARCHAR (10),
	smember_id varchar(10),
	email VARCHAR (20),
	name varchar(10),
	primary key (smember_id),
	foreign key (sbook_id) references books (Book_id),
	foreign key (slib_id) references library (library_id)
);

create table Mem_professor (
	pLib_id VARCHAR (10),
	pbook_id VARCHAR (10),
	pmember_id varchar(10),
	email VARCHAR (20),
	name varchar(10),
	primary key (pmember_id),
	foreign key (pbook_id) references books (Book_id),
	foreign key (plib_id) references library (library_id)
);
